# Welcome To Our Big-Concert Programme

Take a look To Our Page [View Live Site](https://anik-big-concerts.netlify.app/).

## What We Used !!
● React
● JavaScript
● HTML 
● Css

## In this project , you can see:

● Many Singers List
● Their Fees and other Information
● Our Total Budget

## Our Goal :
● To Represent Our Country in a different method.

## Maximum Budget : $ 3,000,00 !!



